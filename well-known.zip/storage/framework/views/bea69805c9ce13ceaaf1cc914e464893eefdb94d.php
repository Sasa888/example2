<?php $__env->startSection('admin-content'); ?>

	<div class="admin-header">
		<h1>Create Page</h1>
		<span class="last-update"></span>
	</div>

	<div class="admin-content">
		<?php if(session('error')): ?>
		    <span class="alert alert-error">
		        <?php echo e(session('error')); ?>

		    </span>
		<?php endif; ?>

		<form action="pages/save" method="post">
			<?php echo e(csrf_field()); ?>


			<?php if($errors->first('title')): ?>
			    <div class="alert alert-error no-hide">
			        <span class="help-block">
			            <strong><?php echo e($errors->first('title')); ?></strong>
			        </span>
			    </div>
			<?php endif; ?> 

			<label>Title</label>
			<input type="text" name="title" placeholder="Page title" value="<?php echo e(old('title')); ?>">

			<?php if($errors->first('elements_prefix')): ?>
			    <div class="alert alert-error no-hide">
			        <span class="help-block">
			            <strong><?php echo e($errors->first('elements_prefix')); ?></strong>
			        </span>
			    </div>
			<?php endif; ?> 

			<label>Elements Prefix</label>
			<input type="text" name="elements_prefix" placeholder="Elements Prefix" value="<?php echo e(old('elements_prefix')); ?>">

			<?php if($errors->first('slug')): ?>
			    <div class="alert alert-error no-hide">
			        <span class="help-block">
			            <strong><?php echo e($errors->first('slug')); ?></strong>
			        </span>
			    </div>
			<?php endif; ?> 

			<label>Slug</label>
			<input type="text" name="slug" placeholder="Slug" value="<?php echo e(old('slug')); ?>">

			<label>Keywords</label>
			<input type="text" name="keywords" placeholder="Keywords" value="<?php echo e(old('keywords')); ?>">

			<?php if($errors->first('description')): ?>
			    <div class="alert alert-error no-hide">
			        <span class="help-block">
			            <strong><?php echo e($errors->first('description')); ?></strong>
			        </span>
			    </div>
			<?php endif; ?> 

			<label>Description</label>
			<textarea name="description" class="htmlEditorTools" rows="5" placeholder="Description"><?php echo e(old('description')); ?></textarea>
			
			<div class="cf">
				<label>Parent page</label>

				<div class="select-style">
					<select name="parent_id">
						<option value="">Choose parent page</option>
					
						<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
							<option value="<?php echo e($parent->id); ?>" <?php echo e($parent->id == $page_id ? 'selected="selected"' : ''); ?>><?php echo e($parent->title); ?></option>
							
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			</div>

			<input type="submit" value="Create" class="save-item">
			<a href="<?php echo e(url()->previous()); ?>" class="button back-button">Back</a>
		</form>
	</div>

	

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin::layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>