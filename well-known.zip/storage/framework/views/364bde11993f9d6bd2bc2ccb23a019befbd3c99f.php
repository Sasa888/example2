<?php $__env->startSection('content'); ?>


<body>

Amount:  <input type="text" name="mytext[]" class="Pixels" value="900"></input>
   
Total:   <input type="text" name="mytext[]" class="Percentage" value="740"></input>

   

<script type="text/javascript">

	$(document).ready(function(){
	
	
		var X = 80;
		$('.Pixels').keyup(function(){
			
			if(!isNaN(this.value)){
			   $('.Percentage').val(parseInt(this.value)/X *100)
			}
		});

		$('.Percentage').keyup(function(){
			$('.Pixels').val(parseInt(this.value) * X/100);
			
		});
		
	});
		
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(URL::to('js/checkbox.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>