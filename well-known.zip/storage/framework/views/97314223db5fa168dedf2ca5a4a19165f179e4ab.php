<?php $__env->startSection('admin-content'); ?>

	<div class="admin-header">
		<h1>Galleries</h1>
		<span class="last-update"></span>
		<div class="button-wrap">
			<a href="galleries/create" class="button right">Create Gallery</a>
		</div>
	</div>

	<div class="admin-content">
		<ul class="border">
			<?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><a href="galleries/edit/<?php echo e($gallery->id); ?>"><b><?php echo e(ucfirst($gallery->title)); ?></a></li>
				
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
		
	</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>