
setTimeout("location.replace('http://check.in.rs/home')",3000);
