

<?php $__env->startSection('admin-content'); ?>
	
	<div class="admin-header">
		<h1>Latest Posts</h1>
		<span class="last-update"></span>
		<div class="button-wrap">
			<a href="blog/post-new" class="button right">Add new</a>
		</div>
	</div>

	<div class="admin-content">

		<?php if(session('success')): ?>
		    <span class="alert alert-success">
		        <?php echo e(session('success')); ?>

		    </span>
		<?php endif; ?>
		
		<?php if(!empty($posts->first())): ?>
			<ul>
			<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as &$post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><a href="blog/post-edit/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>

			<?php echo $posts->render(); ?>

		<?php endif; ?>	



		<?php if(!empty($comments->first())): ?>
			<div class="section-header">
				<span>Latest Comments</span>
				<div class="line"></div>
			</div>
		
			<ul class="comments border">
			<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as &$comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<li class="cf <?php if(!$comment->approved): ?>disapproved <?php endif; ?>">
					<a class="article-title" href="blog/post-edit/<?php echo e($comment->post->id); ?>" target="_blank"><?php echo e($comment->post->title); ?></a>
					<div class="name"><?php echo e($comment->name); ?> / <?php echo e($comment->email); ?></div>
					<p><?php echo e($comment->content); ?></p>
					<div class="created_at"><?php echo e($comment->created_at->format('Y-m-d H:i')); ?>h</div>

					<?php if($comment->approved): ?>
						<a class="action button" href="blog/disapprove-comment/<?php echo e($comment->id); ?>">Disapprove</a>
					<?php else: ?>
						<a class="action button disapproved" href="blog/approve-comment/<?php echo e($comment->id); ?>">Approve</a>
					<?php endif; ?>
				</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>

		<?php echo $comments->render(); ?>

		<?php endif; ?>	
		
		
	</div>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>