

<?php $__env->startSection('admin-content'); ?>

	<div class="admin-header">
		<h1>Pages</h1>
		<span class="last-update"></span>
		<div class="button-wrap">
			<a href="pages/create" class="button right">Create page</a>
		</div>
	</div>

	<div class="admin-content">
		<div class="pages-list">
			<?php echo $navigation; ?>

		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin::layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>