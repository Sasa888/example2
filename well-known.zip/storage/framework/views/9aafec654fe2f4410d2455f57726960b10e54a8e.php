<?php $__env->startSection('admin-content'); ?>

	<div class="admin-header">
		<h1>Edit <?php echo e($admin->name); ?></h1>
		<span class="last-update">Last change: <?php echo e($admin->updated_at->tz('CET')->format('d M Y, H:i\h')); ?></span>
		<div class="button-wrap">
			<a href="settings/add-admin" class="button right">Add Admin</a>
		</div>
	</div>

	<div class="admin-content">
	
		<?php if(session('error')): ?>
		    <span class="alert alert-error">
		        <?php echo e(session('error')); ?>

		    </span>
		<?php endif; ?>

		<form action="settings/update-admin/<?php echo e($admin->id); ?>" method="post">
			
			<?php echo e(csrf_field()); ?>


			<label>Admin name</label>
			<input type="text" name="name" placeholder="Admin name" value="<?php echo e($admin->name); ?>">

			<label>Admin email</label>
			<input type="text" name="email" placeholder="Admin email" value="<?php echo e($admin->email); ?>">

			<input type="submit" value="Save" class="save-item">
		</form>
		<br>
		<div class="section-header">
			<span>Change Administrator's Password</span>
			<div class="line"></div>
		</div>
		<br><br>
		<div class="cf"></div>

		<?php if(session('success')): ?>
		    <span class="alert alert-success">
		        <?php echo e(session('success')); ?>

		    </span>
		<?php endif; ?>

		<?php if(session('pass')): ?>
		    <span class="alert alert-error">
		        <?php echo e(session('pass')); ?>

		    </span>
		<?php endif; ?>

		<form action="settings/change-password/<?php echo e($admin->id); ?>" method="post">
			<input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>">
					
			<label>Old Password</label>
			<input name="old_pass" type="password">

			<label>New Password</label>
			<input name="new_pass" type="password">

			<label>Repeat Password</label>
			<input name="confirm_pass" type="password">

			<input type="submit" value="Save" class="save-item">
		</form>
		
	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>