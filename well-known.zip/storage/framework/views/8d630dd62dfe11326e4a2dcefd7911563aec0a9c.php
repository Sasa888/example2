

<?php $__env->startSection('admin-content'); ?>

	<div class="admin-header">
		<h1>Shop</h1>
		<span class="last-update"></span>
	</div>

	<div class="admin-content">
		
		
	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>