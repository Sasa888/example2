<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><strong>Select your gift</strong></div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                        <h4><strong>Usage of IT device</strong></h4>
                        <p>The employee can use one of the following IT devices. The devices remain property of the employer until end of depreciation. Benefit in kind can apply on private use</p>
                    <br>
                    <br>
                        <div class="row">

                                  <div class="col-6 col-md-4"><strong><a href="https://www.apple.com/iphone-8/"><h3>iPhone</h3></a></strong><hr><br><br>
                                      <div class="form-check">
                                         <input class="form-check-input" type="checkbox" value="500" id="defaultCheck1">
                                             <label class="form-check-label" for="defaultCheck1">
                                                 8 - 64 GB - 500&euro;
                                            </label><br>

                                         <input class="form-check-input" type="checkbox" value="550" id="defaultCheck1">
                                             <label class="form-check-label" for="defaultCheck1">
                                                 8 - 256 GB - 550&euro;
                                            </label><br>

                                          <input class="form-check-input" type="checkbox" value="800" id="defaultCheck1">
                                             <label class="form-check-label" for="defaultCheck1">
                                                X 256 GB - 800&euro;
                                            </label>
                                     </div><br>

                                  </div>


                                   <div class="col-6 col-md-4"><strong><a href="https://www.apple.com/ipad/"><h3>iPod</h3></a></strong><hr><br><br>
                                      <div class="form-check">
                                         <input class="form-check-input" type="checkbox" value="450" id="defaultCheck1">
                                             <label class="form-check-label" for="defaultCheck1">
                                                Pro 10,5  Inch 64GB - 450&euro;
                                             </label><br>
                                        <input class="form-check-input" type="checkbox" value="550" id="defaultCheck1">
                                             <label class="form-check-label" for="defaultCheck1">
                                                 Pro 10,5  Inch 256GB - 550&euro;
                                            </label><br>
                                        <input class="form-check-input" type="checkbox" value="650" id="defaultCheck1">
                                             <label class="form-check-label" for="defaultCheck1">
                                                 Pro 12,9  Inch 256GB - 650&euro;
                                            </label><br>
                                    </div>   
                                  </div>
                                  

                             
                                  <div class="col-6 col-md-4"><strong><a href="https://www.apple.com/imac/"><h3>iMac</h3></a></strong><hr><br><br>
                                      <div class="form-check">
                                         <input class="form-check-input" type="checkbox" value="1000" id="defaultCheck1">
                                             <label class="form-check-label" for="defaultCheck1">
                                                    4K 3 Ghz 21,5' - 1000&euro;
                                            </label><br>

                                         <input class="form-check-input" type="checkbox" value="1500" id="defaultCheck1">
                                             <label class="form-check-label" for="defaultCheck1">
                                                  5K 3,5 Ghz 27' - 1500&euro;
                                            </label>
                                    </div>   
                                  </div>      

                        </div><br>
                               <p><small>**Please note that you can choose max one iPhone and one iPod or iMac</small></p> 
 
                            <hr>

                    <h4><strong>Reimburse Pension 3th pillar</strong></h4>
                    <p>By selecting this option, I confirm to deliver scan of attestation of last year to Hr.be.payroll@kuehne-nagel.com.  Scan named "last name + year". This option provide a max profit 200 euro net</p>
                    <label class="checkbox-inline">
                        <input type="checkbox" value="">Yes
                    </label>
                    <label class="checkbox-inline">
                         <input type="checkbox" value="">No
                    </label>

                    <hr>

                     <h4><strong>Remainder can be paid in Warrants</strong></h4>
                    <p>Bonusamount will be increased with 25% for warrants. Option provide a higher net pay out than cash payment</p>
                    <label class="checkbox-inline">
                        <input type="checkbox" value="">Yes
                    </label>
                    <label class="checkbox-inline">
                         <input type="checkbox" value="">No
                    </label>
                    <br><br><br>

                    <a class="btn btn-primary btn-lg" href="#" role="button">CONFIRM & SEND</a>

                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>