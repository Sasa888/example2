<?php

namespace App\Http\Controllers\SLA;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;

class UsersController extends Controller
{
    
    public function index()
    {
        $users = User::get();
        
        return view('sla.users.index', compact('users'));
    }
    
     
}
