<?php

Route::get('users', 'SLA\UsersController@index');
