<?php $__env->startSection('admin-content'); ?>
	
	<div class="admin-header">
		<h1>Leads</h1>
		<span class="last-update"></span>
		<div class="button-wrap">
			<a href="leads/settings" class="button right">Settings</a>
			<a href="leads/email-leads" class="button right">Email leeds</a>
		</div>
	</div>

	<div class="admin-content">

		<table class="lead-table">
			<?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as &$lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php $json = json_decode($lead->data);?>
				<tr onclick="document.location='leads/edit/<?php echo e($lead->id); ?>'" style="cursor:pointer">
					<td><?php echo e($lead->updated_at); ?></td>
					<td><?php echo e($json->email); ?></td>
					<td><a href="leads/delete/<?php echo e($lead->id); ?>" class="button remove-item delete" style="margin:0">Delete lead</a></td>
				</tr>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>

		<?php if(!empty($leads)): ?>
			<?php echo e($leads->render()); ?>

		<?php endif; ?>
		
		
	</div>

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>