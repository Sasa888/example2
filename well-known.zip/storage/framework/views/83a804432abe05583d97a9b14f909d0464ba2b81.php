

<?php $__env->startSection('admin-content'); ?>

	<div class="admin-header">
		<h1>Settings</h1>
		<span class="last-update"></span>
		<div class="button-wrap">
			<a href="settings/add-admin" class="button right">Add Admin</a>
		</div>
	</div>

	<div class="admin-content">
		<form action="settings/update" method="post" enctype="multipart/form-data">
			
			<?php echo e(csrf_field()); ?>


			<label>Admin panel Title</label>
			<input type="text" name="title" placeholder="Admin panel title" value="<?php echo e(@$setting->title); ?>">

		    <div class="fileUpload">
				<span>Change logo</span>
				<input type="file" name="logo">
			</div>
			<div class="cf"></div>

			<input type="submit" value="Save" class="save-item">
		</form>

		<div class="section-header">
			<span>Admins</span>
			<div class="line"></div>
		</div>
		<span class="last-update"></span>
		
		<ul>
			<?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as &$admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><a href="settings/edit/<?php echo e($admin->id); ?>"><b><?php echo e($admin->name); ?></a></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
		
		
	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>