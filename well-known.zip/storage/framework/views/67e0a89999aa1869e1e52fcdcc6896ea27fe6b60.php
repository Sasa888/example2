<?php $__env->startSection('admin-content'); ?>

	<div class="admin-header">
		<h1>Add element in <?php echo e($page->title); ?> page</h1>	
		<span class="last-update"></span>
	</div>

	<div class="admin-content">
		<form action="pages/add-element/<?php echo e($page->id); ?>" method="post" enctype="multipart/form-data">
			<?php echo e(csrf_field()); ?>


			<input type="hidden" name="elements_prefix" value="<?php echo e(isset($page->elements_prefix) ? $page->elements_prefix : old('title')); ?>">
			<input type="hidden" name="page_element_type_id" value="<?php echo e(isset($page_element_type_id) ? $page_element_type_id : old('page_element_type_id')); ?>">
		
			<?php if($errors->first('title')): ?>
			    <div class="alert alert-error no-hide">
			        <span class="help-block">
			            <strong><?php echo e($errors->first('title')); ?></strong>
			        </span>
			    </div>
			<?php endif; ?> 

			<label>Title</label>
			<input type="text" name="title" placeholder="Page title" value="<?php echo e(old('title')); ?>">
		
			<?php if($errors->first('content')): ?>
			    <div class="alert alert-error no-hide">
			        <span class="help-block">
			            <strong><?php echo e($errors->first('content')); ?></strong>
			        </span>
			    </div>
			<?php endif; ?> 
		
			<div class="cf">
				<?php if($page_element_type_id == 1 || old('page_element_type_id') == 1): ?>
				
					<label>Content</label>
					<textarea name="content" rows="5" placeholder="Content"><?php echo e(old('content')); ?></textarea>
					
				<?php elseif($page_element_type_id == 2 || old('page_element_type_id') == 2): ?>
				
					<label>Content</label>
					<textarea name="content" class="htmlEditor" data-page-name="page_element" data-page-id="<?php echo e($page->id); ?>" id="editor-<?php echo e($page->id); ?>" rows="5" placeholder="Content"><?php echo e(old('content')); ?></textarea>
				
				<?php elseif($page_element_type_id == 3 || old('page_element_type_id') == 3): ?>
				
				    <div class="fileUpload">
						<span>Add file</span>
						<input type="file" name="content" multiple="multiple">
					</div>
				
				<?php endif; ?>
			</div>

			<div class="cf">
				<input type="submit" value="Insert" class="save-item">
				<a href="<?php echo e(url()->previous()); ?>" class="button back-button">Back</a>
			</div>
		</form>
	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>