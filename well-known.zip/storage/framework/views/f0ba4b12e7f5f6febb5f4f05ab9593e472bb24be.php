<?php 
dd($users);
 ?>