<?php $__env->startSection('admin-content'); ?>
	
	<div class="admin-header">
		<h1>Edit <?php echo e($page->title); ?> page</h1>
		<span class="last-update">Last change: <?php echo e($page->updated_at->tz('CET')->format('d M, Y, H:i\h')); ?></span>
	</div>

	<div class="admin-content">
		<?php if(session('error')): ?>
		    <span class="alert alert-error">
		        <?php echo e(session('error')); ?>

		    </span>
		<?php endif; ?>		
		<?php if(session('success')): ?>
		    <span class="alert alert-success">
		        <?php echo e(session('success')); ?>

		    </span>
		<?php endif; ?>
		
		<form action="pages/update/<?php echo e($page->id); ?>" method="post">
			<?php echo e(csrf_field()); ?>


			<?php if($errors->first('title')): ?>
			    <div class="alert alert-error no-hide">
			        <span class="help-block">
			            <strong><?php echo e($errors->first('title')); ?></strong>
			        </span>
			    </div>
			<?php endif; ?> 

			<label>Title</label>
			<input type="text" name="title" placeholder="Page title" value="<?php echo e($page->title); ?>">

			<?php if($errors->first('elements_prefix')): ?>
			    <div class="alert alert-error no-hide">
			        <span class="help-block">
			            <strong><?php echo e($errors->first('elements_prefix')); ?></strong>
			        </span>
			    </div>
			<?php endif; ?> 

			<label>Elements Prefix</label>
			<input type="text" name="elements_prefix" placeholder="Elements Prefix" value="<?php echo e($page->elements_prefix); ?>">

			<?php if($errors->first('slug')): ?>
			    <div class="alert alert-error no-hide">
			        <span class="help-block">
			            <strong><?php echo e($errors->first('slug')); ?></strong>
			        </span>
			    </div>
			<?php endif; ?> 

			<label>Slug</label>
			<input type="text" name="slug" placeholder="Slug" value="<?php echo e($page->slug); ?>">

			<label>Keywords</label>
			<input type="text" name="keywords" placeholder="Keywords" value="<?php echo e($page->keywords); ?>">

			<?php if($errors->first('description')): ?>
			    <div class="alert alert-error no-hide">
			        <span class="help-block">
			            <strong><?php echo e($errors->first('description')); ?></strong>
			        </span>
			    </div>
			<?php endif; ?> 

			<label>Description</label>
			<textarea name="description" class="htmlEditorTools" rows="5" placeholder="Description"><?php echo e($page->description); ?></textarea>

			<div class="cf">
				<label>Parent page</label>

				<div class="select-style">
					<select name="parent_id">
						<option value="">Choose parent page</option>
					
						<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
							<?php if($parent->id != $page->id): ?>
								<option value="<?php echo e($parent->id); ?>" <?php echo e($parent->id == $page->parent_id ? 'selected="selected"' : ''); ?>><?php echo e($parent->title); ?></option>
							<?php endif; ?>
							
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>

			</div>

			<input type="submit" value="Update" class="save-item">
			<a href="pages/delete/<?php echo e($page->id); ?>" class="button delete remove-item">Delete page</a>
			<a href="<?php echo e(url()->previous()); ?>" class="button back-button">Back</a>
		</form>

		<div>
		</div>

		<div class="cf">
			<div class="section-header">
				<span>Elements</span>
				<div class="line"></div>
			</div>

			<?php if(!empty($page->elements->first())): ?>
				
				<ul class="elements-list sortable" data-link="ajax/<?php echo e($page->id); ?>/change-page-element-order">
					<?php $__currentLoopData = $page->elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li class="items-order" data-id="<?php echo e($element->id); ?>">
							<a href="pages/edit-element/<?php echo e($element->id); ?>"><b><?php echo e(ucfirst($element->title)); ?> <?php  echo env('APP_ENV') == 'local' ? ' - '.$element->key : ''  ?></b></a>
							<a href="pages/delete-element/<?php echo e($element->id); ?>" class="button remove-item file delete list">Delete</a>
						</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			<?php else: ?>
				<p>No elements yet</p>
			<?php endif; ?>
			
			<form action="pages/new-element/<?php echo e($page->id); ?>" method="post">
				<?php echo e(csrf_field()); ?>


				<div class="select-style">
					<select name="page_element_type_id" class="element-type">
						<option value="0">Add element</option>
					
						<?php $__currentLoopData = $element_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($element_type->id); ?>"><?php echo e($element_type->title); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			
			</form>
		</div>	


		<div class="cf">
			<div class="section-header">
				<span>Subpages</span>
				<div class="line"></div>
			</div>
			<div class="cf"></div>
			<a href="pages/create/<?php echo e($page->id); ?>" class="button right">Add subpage</a>
			<div class="cf"></div>


			<?php if(!empty($page->subpages())): ?>
				
				<ul class="sortable elements-list cf" data-link="ajax/<?php echo e($page->id); ?>/change-subpages-order">
					<?php $__currentLoopData = $page->subpages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li class="items-order" data-id="<?php echo e($child['id']); ?>">
							<a href="pages/edit/<?php echo e($child['id']); ?>"><b><?php echo e(ucfirst($child['title'])); ?> - <?php echo e($child['slug']); ?></a>
							<a href="pages/delete/<?php echo e($child['id']); ?>" class="button remove-item file delete list">Delete</a>
						</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			<?php else: ?>
				<p>No subpages</p>
			<?php endif; ?>
		</div>	

		
		<script>
			$("body").delegate('.element-type', 'change',function(){

				if ($(this).val() == 0) {
					return false;
				}
				else {
					$(this).closest("form").submit();
				}

			});

		</script>
		
		
	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>