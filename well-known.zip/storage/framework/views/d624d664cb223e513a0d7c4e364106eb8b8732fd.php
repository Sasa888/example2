<?php $__env->startSection('styles'); ?>
    ##parent-placeholder-bf62280f159b1468fff0c96540f3989d41279669##
    <link rel="stylesheet" href="css/login.css">
<?php $__env->appendSection(); ?>


<?php $__env->startSection('body'); ?>

    <div class="logo-login">
        <a href="" class="logo"><img src="<?php echo e((!empty(SystemInc\LaravelAdmin\Setting::first()) && SystemInc\LaravelAdmin\Setting::first()->source != null) ? Storage::url(SystemInc\LaravelAdmin\Setting::first()->source) : 'images/gw.png'); ?>" alt="Great Workplace"></a>
    </div>

    <div class="login-form">

        <?php if($errors->first('login')): ?>
            <div class="alert alert-error no-hide">
                <span class="help-block">
                    <strong><?php echo e($errors->first('login')); ?></strong>
                </span>
            </div>
        <?php endif; ?>

        <form class="form-horizontal" role="form" method="POST" action="login">
            <?php echo e(csrf_field()); ?>


            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">

                <?php if(session('message')): ?>
                    <div class="alert alert-error no-hide">
                        <span class="help-block">
                            <strong><?php echo e(session('message')); ?></strong>
                        </span>
                    </div>
                <?php endif; ?>
                
                <input type="email" name="email" id="name" value="<?php echo e(old('email')); ?>" placeholder="Email Address">

            </div>

            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                
                <input type="password" name="password" id="password" placeholder="Password">

            </div>


            <button class="button full-button">Log in</button>

        </form>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.document', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>