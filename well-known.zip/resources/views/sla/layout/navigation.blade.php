<ul>
    <li>
        <a href="users">Users</a>
    </li>
</ul>